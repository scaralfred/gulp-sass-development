var max = 8;

for (var i=0; i <= max; i++) {
    console.log(i)
}

